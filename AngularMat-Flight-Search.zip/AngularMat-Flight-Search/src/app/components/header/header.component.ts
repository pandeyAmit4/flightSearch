import { Component, HostBinding, Renderer2, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { OverlayContainer } from '@angular/cdk/overlay';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
})
export class HeaderComponent implements OnInit {
  color = 'warn';
  checked = 'true';
  @HostBinding('class') className = '';
  toggleControl = new FormControl(false);
  constructor(
    private dialog: MatDialog,
    private overlay: OverlayContainer,
    private renderer: Renderer2
  ) {}

  ngOnInit(): void {
    this.toggleControl.valueChanges.subscribe((darkMode) => {
      const darkClassName = 'darkMode';
      this.className = darkMode ? darkClassName : '';
      if (darkMode) {
        this.renderer.addClass(document.body, darkClassName);
        //this.overlay.getContainerElement().classList.add(darkClassName);
      } else {
        this.renderer.removeClass(document.body, darkClassName);
        //this.overlay.getContainerElement().classList.remove(darkClassName);
      }
    });
  }
}
