import { Component, Input, OnInit } from '@angular/core';
// import { NouisliderModule } from 'ng2-nouislider';
import { FlightModel } from './../interface/flight-model';
import { FlightService } from './../service/flight.service';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-flight-search',
  templateUrl: './flight-search.component.html',
  styleUrls: ['./flight-search.component.css'],
})
export class FlightSearchComponent implements OnInit {
  // Necessary variable declarations which will be used in html
  flight: FlightModel;
  flightInput: FlightModel[] = [];
  someRange: Array<any> = [];
  displayRetField: String = 'no';
  removed: FlightModel[] = [];
  minDate = new Date();
  maxDate = new Date(2020, 0, 1);
  selectedValue: string;
  flightArr: Array<FlightModel[]> = [];
  formGroup: FormGroup;
  titleAlert: string = 'This field is required';

  // Using constructor, call the FlightService.
  constructor(
    private _flightService: FlightService,
    private formBuilder: FormBuilder
  ) {}
  ngOnInit() {
    // Initializing values in flight model
    this.someRange = [1000, 5000];
    // this.minDate.setDate(this.minDate.getDate() - 1);
    this.createForm();
    this.setChangeValidate();
    this.flight = {
      id: null,
      FlightCode: '',
      SeatsAvailable: null,
      OriginDestination: {
        Origin: '',
        Destination: '',
        DeptDate: null,
        ArrDate: null,
      },
      FareDetails: null,
    };
  }

  createForm() {
    this.formGroup = this.formBuilder.group({
      originCity: [null, Validators.required],
      destinationCity: [null, [Validators.required]],
      departureDate: [null, [Validators.required]],
      returnDate: [null, [Validators.required]],
      passangerCount: [null, [Validators.required]],
      priceRange: [null, [Validators.required]],
      validate: '',
    });
  }

  setChangeValidate() {
    this.formGroup.get('validate').valueChanges.subscribe((validate) => {
      if (validate == '1') {
        this.formGroup
          .get('name')
          .setValidators([Validators.required, Validators.minLength(3)]);
        this.titleAlert = 'You need to specify at least 3 characters';
      } else {
        this.formGroup.get('name').setValidators(Validators.required);
      }
      this.formGroup.get('name').updateValueAndValidity();
    });
  }

  get name() {
    return this.formGroup.get('name') as FormControl;
  }
  // This function is called from html which in turn calls the functions in our Flight service.
  searchFlights(vals) {
    if (this.displayRetField == 'yes') {
      console.log('display ret');
      // Assign input values from user.
      this.flightInput = [
        // When the trip type is two-way
        {
          id: null,
          FlightCode: '',
          SeatsAvailable: vals.passangerCount,
          OriginDestination: {
            Origin: vals.originCity,
            Destination: vals.destinationCity,
            DeptDate: vals.departureDate,
            ArrDate: null,
          },
          FareDetails: null,
        },
        {
          id: null,
          FlightCode: '',
          SeatsAvailable: vals.passangerCount,
          OriginDestination: {
            Origin: vals.destinationCity,
            Destination: vals.originCity,
            DeptDate: vals.returnDate,
            ArrDate: null,
          },
          FareDetails: null,
        },
      ];
    } else {
      console.log('no display ret');
      this.flightInput = [
        // When trip type is one way
        {
          id: null,
          FlightCode: '',
          SeatsAvailable: vals.passangerCount,
          OriginDestination: {
            Origin: vals.originCity,
            Destination: vals.destinationCity,
            DeptDate: vals.departureDate,
            ArrDate: null,
          },
          FareDetails: null,
        },
      ];
    }
    // Service function called to add person details to array
    this.flightArr = this._flightService.getFlightDetails(
      this.flightInput,
      this.someRange[0],
      this.someRange[1]
    );
  }

  retDt = new FormControl('', [Validators.required]);

  getErrorMessage() {
    return this.retDt.hasError('required')
      ? 'You must enter a value'
      : this.retDt.hasError('retDt')
      ? 'Not a valid email'
      : '';
  }

  noResults() {
    // Conditions to check whether or not to display results
    if (
      this.flightArr.length == 0 ||
      (this.displayRetField == 'no' && this.flightArr[0].length == 0) ||
      (this.displayRetField == 'yes' && this.flightArr[1].length == 0)
    ) {
      return true;
    }
  }

  // Price range slider function
  onChange($event) {
    this.flightArr = this._flightService.getFlightDetails(
      this.flightInput,
      this.someRange[0],
      this.someRange[1]
    );
  }
}
