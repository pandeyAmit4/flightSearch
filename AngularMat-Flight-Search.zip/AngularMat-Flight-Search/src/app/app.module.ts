import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SigninComponent } from './components/signin/signin.component';
import { RegisterComponent } from './components/register/register.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AngularMaterialModule } from './angular-material.module';
import { FlexLayoutModule } from "@angular/flex-layout";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlightSearchComponent } from './components/flight-search/flight-search.component';
import { FlightSearchResultComponent } from './components/flight-search-result/flight-search-result.component';
import { FlightService } from './components/service/flight.service';

import { InMemoryWebApiModule } from 'angular-in-memory-web-api';
import { InMemoryDataService } from './in-memory-data.service';
import { HttpClientModule, HTTP_INTERCEPTORS} from '@angular/common/http';
// import { AuthHttpInterceptor } from './components/service/auth.service';
import { NouisliderModule } from 'ng2-nouislider';
import { DatePipe } from '@angular/common';
import { HeaderComponent } from './components/header/header.component';
//import { MaterialModule } from './modules/material/material.module';



@NgModule({
  declarations: [
    AppComponent,
    SigninComponent,
    RegisterComponent,
    FlightSearchComponent,
    FlightSearchResultComponent,
    HeaderComponent,
  ],
  imports: [
    HttpClientModule,
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    AngularMaterialModule,
    FormsModule,
    NouisliderModule,
    FlexLayoutModule,
    InMemoryWebApiModule.forRoot(InMemoryDataService),
    ReactiveFormsModule,
  ],
  providers: [
    FlightService,
    DatePipe,
  ],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class AppModule {}