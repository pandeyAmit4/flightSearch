import { Component, OnInit } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  postId = null;
  title = 'Flight Search';
  // tokenUrl = 'https://test.api.amadeus.com/v1/security/oauth2/token';
  // headers = new HttpHeaders({
  //   'Content-Type': 'application/json',
  //   Authorization: 'my-auth-token',
  // });
  // body = JSON.stringify({
  //   grant_type: 'client_credentials',
  //   client_id: 'G5nmEzAt5LdK0gwLrTCTFG2TdsqTko05',
  //   client_secret: 'shh6c6lpJBPQ5Yr0',
  // });
  constructor(private http: HttpClient) {}

  // ngOnInit() {
  //   // Simple POST request with a JSON body and response type <any>
  //   this.http
  //     .post<any>(this.tokenUrl, this.body, {
  //       headers: this.headers,
  //     })
  //     .subscribe((data) => {
  //       this.postId = data.id;
  //     });
  // }
}